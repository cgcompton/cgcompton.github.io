Charles Compton Jr. — sports videography portfolio.
Open index.html locally to preview. Upload the entire contents of this folder (including media/) to a static host such as Netlify or GitHub Pages.
Four uploaded video samples are playable in the website. Confirm editing rights, underlying footage/music licenses and individual credits before public publication. TikTok links are not verified as matching the four uploaded files. LinkedIn and YouTube links are included.

Basketball reel: all shots filmed and edited by Charles Compton Jr. (confirmed by creator).
